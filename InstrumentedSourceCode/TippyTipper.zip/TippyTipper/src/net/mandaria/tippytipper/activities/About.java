package net.mandaria.tippytipper.activities;

import com.flurry.android.FlurryAgent;

import net.mandaria.tippytipper.R;
import android.app.Activity;
import android.os.Bundle;

import it.unina.dieti.logcelot.Logcelot;

public class About extends Activity  {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
        Logcelot.log("About.onCreate()");
    }
    
    @Override
	public void onStart()
    {
       super.onStart();
        Logcelot.log("About.onStart()");
       boolean enableErrorLogging = Settings.getEnableErrorLogging(getBaseContext());
       String API = getString(R.string.flurrykey);
       if(!API.equals("") && enableErrorLogging == true)
       {
           Logcelot.log("About.onStart()(!API.equals(\"\") && enableErrorLogging == true)");
    	   FlurryAgent.setContinueSessionMillis(30000);
    	   FlurryAgent.onStartSession(this, API);
       }
    }
    
    @Override
	public void onStop()
    {
       super.onStop();
        Logcelot.log("About.onStop()");
       FlurryAgent.onEndSession(this);
    }
}