package net.mandaria.tippytipper.activities;

import net.mandaria.tippytipper.R;
import android.app.Activity;
import android.os.Bundle;

import it.unina.dieti.logcelot.Logcelot;

public class Test extends Activity  {
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Logcelot.log("Test.onCreate()");
        try
        {
            Logcelot.log("Test.onCreate().try");
        setContentView(R.layout.test);  
        }
        catch(Exception ex)
        {
            Logcelot.log("Test.onCreate().try.catch");
        	String test = "";
        }
        
    }

}