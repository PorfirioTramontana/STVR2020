  package net.mandaria.tippytipper;

import net.mandaria.tippytipper.services.TipCalculatorService;
import android.app.*;

import it.unina.dieti.logcelot.Logcelot;

  public class TippyTipperApplication extends Application {
	
	public TipCalculatorService service = new TipCalculatorService();
	
	
	@Override
	public void onCreate() 
	{ 
		super.onCreate();
		Logcelot.log("TippyTipperApplication.onCreate");
	}
} 
