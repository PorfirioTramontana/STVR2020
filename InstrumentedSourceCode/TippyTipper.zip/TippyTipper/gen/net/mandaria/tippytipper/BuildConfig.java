/** Automatically generated file. DO NOT MODIFY */
package net.mandaria.tippytipper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}