/*
 * Copyright (C) 2010 Keith Kildare
 * 
 * This file is part of SimplyDo.
 * 
 * SimplyDo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SimplyDo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with SimplyDo.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package kdk.android.simplydo;

import java.io.Serializable;

import it.unina.dieti.logcelot.Logcelot;

public class ListDesc implements Serializable
{
    private static final long serialVersionUID = 1L;
    
    
    private int id;
	private String label;
	private int activeItems;
	private int totalItems;
	
    public ListDesc()
    {
		Logcelot.log( "ListDesc.ListDesc()");
        // Do nothing
    }
    
    
	public ListDesc(int id, String label, int activeItems, int totalItems)
	{
		Logcelot.log( "ListDesc.ListDesc()");
		this.id = id;
		this.label = label;
		this.activeItems = activeItems;
		this.totalItems = totalItems;
	}

	public int getId()
	{
		Logcelot.log( "ListDesc.getId()");
		return id;
	}

	public void setId(int id)
	{
		Logcelot.log( "ListDesc.setId()");
		this.id = id;
	}

	public String getLabel()
	{
		Logcelot.log( "ListDesc.getLabel()");
		return label;
	}

	public void setLabel(String label)
	{
		Logcelot.log( "ListDesc.setLabel()");
		this.label = label;
	}
	
	public int getActiveItems()
	{
		Logcelot.log( "ListDesc.getActiveItems()");
		return activeItems;
	}

	public void setActiveItems(int inactiveItems)
	{
		Logcelot.log( "ListDesc.setActiveItems()");
		this.activeItems = inactiveItems;
	}

	public int getTotalItems()
	{
		Logcelot.log( "ListDesc.getTotalItems()");
		return totalItems;
	}

	public void setTotalItems(int totalItems)
	{
		Logcelot.log( "ListDesc.setTotalItems()");
		this.totalItems = totalItems;
	}
	
	
	
}
