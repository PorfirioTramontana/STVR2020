/*
 * Copyright (C) 2010 Keith Kildare
 * 
 * This file is part of SimplyDo.
 * 
 * SimplyDo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SimplyDo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with SimplyDo.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package kdk.android.simplydo;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import android.util.Log;

import it.unina.dieti.logcelot.Logcelot;

public class ItemListSorter
{
    public static final String PREF_NONE = "none";
    public static final String PREF_STARRED = "starred";
    public static final String PREF_ACTIVE_STARRED = "activityStarred";
    
    private static final int NONE = 0;
    private static final int STARRED = 1;
    private static final int ACTIVE_STARRED = 2;

    private int sortingMode;
    
    private Comparator<ItemDesc> idCompare;
    private Comparator<ItemDesc> starredCompare;
    private Comparator<ItemDesc> activeStarredCompare;

    
    public ItemListSorter()
    {
        Logcelot.log( "ItemListSorter.ItemListSorter()");
        idCompare = new Comparator<ItemDesc>() {
            @Override
            public int compare(ItemDesc object1, ItemDesc object2)
            {
                Logcelot.log( "ItemListSorter.ItemListSorter().idCompare.compare()");
                return object2.getId() - object1.getId();
            }
        };
        
        starredCompare = new Comparator<ItemDesc>() {
            @Override
            public int compare(ItemDesc o1, ItemDesc o2)
            {
                Logcelot.log( "ItemListSorter.ItemListSorter().starredCompare.compare()");
                int w1 = o1.isStar()?1:0;
                int w2 = o2.isStar()?1:0;
                if(w2 == w1)
                {
                    Logcelot.log( "ItemListSorter.ItemListSorter().starredCompare.compare().w2==w1");
                    return o1.getLabel().compareToIgnoreCase(o2.getLabel());
                }
                else
                {
                    Logcelot.log( "ItemListSorter.ItemListSorter().starredCompare.compare().w2!=w1");
                    return w2 - w1;
                }
            }
        };
        
        activeStarredCompare = new Comparator<ItemDesc>() {
            @Override
            public int compare(ItemDesc o1, ItemDesc o2)
            {
                Logcelot.log( "ItemListSorter.ItemListSorter().activeStarredCompare.compare()");
                int w1 = (o1.isStar()?1:0) + (o1.isActive()?0:-2);
                int w2 = (o2.isStar()?1:0) + (o2.isActive()?0:-2);
                if(w2 == w1)
                {
                    Logcelot.log( "ItemListSorter.ItemListSorter().activeStarredCompare.compare().w2==w1");
                    return o1.getLabel().compareToIgnoreCase(o2.getLabel());
                }
                else
                {
                    Logcelot.log( "ItemListSorter.ItemListSorter().activeStarredCompare.compare().w2!=w1");
                    return w2 - w1;
                }
            }
        };
    }
    
    public void setSortingMode(String mode)
    {
        Logcelot.log( "ItemListSorter.setSortingMode()");
        if(PREF_NONE.equals(mode))
        {
            Logcelot.log( "ItemListSorter.setSortingMode().PREF_NONE.equals(mode)");
            sortingMode = NONE;
        }
        else if(PREF_STARRED.equals(mode))
        {
            Logcelot.log( "ItemListSorter.setSortingMode().REF_STARRED.equals(mode)");
            sortingMode = STARRED;
        }
        else if(PREF_ACTIVE_STARRED.equals(mode))
        {
            Logcelot.log( "ItemListSorter.setSortingMode().PREF_ACTIVE_STARRED.equals(mode)");
            sortingMode = ACTIVE_STARRED;
        }
        else
        {
            Logcelot.log( "ItemListSorter.setSortingMode().!PREF_ACTIVE_STARRED.equals(mode)");
            sortingMode = NONE;
            Log.w(L.TAG, "Unknown item sorting mode " + mode);
        }
    }
    
    
    public void markEditUpdate(ItemDesc item)
    {
        Logcelot.log( "ItemListSorter.markEditUpdate()");
        switch(sortingMode)
        {
        case ACTIVE_STARRED:
            Logcelot.log( "ItemListSorter.markEditUpdate().caseACTIVE_STARRED");
        case STARRED:
            Logcelot.log( "ItemListSorter.markEditUpdate().caseSTARRED");
            item.setSorted(false);
            break;
        }        
    }
    
    
    public void markActivityUpdate(ItemDesc item)
    {
        Logcelot.log( "ItemListSorter.markActivityUpdate()");
        switch(sortingMode)
        {
        case ACTIVE_STARRED:
            Logcelot.log( "ItemListSorter.markActivityUpdate().caseACTIVE_STARRED");
            item.setSorted(false);
            break;
        }        
    }
    
    
    public void markStarredUpdate(ItemDesc item)
    {
        Logcelot.log( "ItemListSorter.marKStarredUpdate()");
        switch(sortingMode)
        {
        case ACTIVE_STARRED:
            Logcelot.log( "ItemListSorter.marKStarredUpdate().caseACTIVE_STARRED");
        case STARRED:
            Logcelot.log( "ItemListSorter.marKStarredUpdate().case_STARRED");
            item.setSorted(false);
            break;
        }        
    }
    
    
    public void sort(List<ItemDesc> list)
    {
        Logcelot.log( "ItemListSorter.sort()");
        if(list == null)
        {
            Logcelot.log( "ItemListSorter.sort().list==null");
            return;
        }

        Logcelot.log( "ItemListSorter.sort().list!=null");
        switch(sortingMode)
        {
        default:
            Logcelot.log( "ItemListSorter.sort().caseDEFAULT");
            Log.w(L.TAG, "Unknown item sorting enum " + sortingMode);
            // fall through
        case NONE:
            Logcelot.log( "ItemListSorter.sort().caseNONE");
            // actually sorted by db id
            Collections.sort(list, idCompare);
            break;
        case STARRED:
            Logcelot.log( "ItemListSorter.sort().caseSTARRED");
            Collections.sort(list, starredCompare);
            break;
        case ACTIVE_STARRED:
            Logcelot.log( "ItemListSorter.sort().caseACTIVE_STARRED");
            Collections.sort(list, activeStarredCompare);
            break;
        }
        
        markAsSorted(list);
    }

    private void markAsSorted(List<ItemDesc> items)
    {
        Logcelot.log( "ItemListSorter.markAsSorted()");
        for(ItemDesc item : items)
        {
            Logcelot.log( "ItemListSorter.markAsSorted().for.ItemDesc");
            item.setSorted(true);
        }
    }
}
