/*
 * Copyright (C) 2010, 2011 Keith Kildare
 * 
 * This file is part of SimplyDo.
 * 
 * SimplyDo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SimplyDo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with SimplyDo.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package kdk.android.simplydo;

import java.util.ArrayList;
import java.util.List;

import android.util.Log;

import it.unina.dieti.logcelot.Logcelot;

public class SimpleDataViewer implements DataViewer
{
    private DataManager dataManager;

    private List<ItemDesc> itemData = new ArrayList<ItemDesc>();
    private List<ListDesc> listData = new ArrayList<ListDesc>();
    
    private ListDesc selectedList;

    
    public SimpleDataViewer(DataManager dataManager)
    {
        Logcelot.log( "SimpleDataViewer.SimpleDataViewer()");
        this.dataManager = dataManager;
    }
    
    
    @Override
    public List<ItemDesc> getItemData()
    {
        Logcelot.log( "SimpleDataViewer.getItemData()");
        return itemData;
    }

    
    @Override
    public List<ListDesc> getListData()
    {
        Logcelot.log( "SimpleDataViewer.getListData()");
        return listData;
    }
    
    @Override
    public void setSelectedList(ListDesc selectedList)
    {
        Logcelot.log( "SimpleDataViewer.setSelectedList()");
        this.selectedList = selectedList;
        if(selectedList == null)
        {
            Logcelot.log( "SimpleDataViewer.setSelectedList().selectedList==null");
            itemData.clear();
        }
        else
        {
            Logcelot.log( "SimpleDataViewer.setSelectedList().selectedList!=null");
            fetchItems(selectedList.getId());
        }           
    }
    
    @Override
    public ListDesc getSelectedList()
    {
        Logcelot.log( "SimpleDataViewer.getSelectedList()");
        return selectedList;
    }
    
    @Override
    public void fetchLists()
    {
        Logcelot.log( "SimpleDataViewer.fetchLists()");
        listData = dataManager.fetchLists();
    }
    
    @Override
    public ListDesc fetchList(int listId)
    {
        Logcelot.log( "SimpleDataViewer.fetchList()");
        ListDesc rv = null;
        
        for(ListDesc list : listData)
        {
            if(list.getId() == listId)
            {
                Logcelot.log( "SimpleDataViewer.fetchList().list.getId()==listId");
                rv = list;
                break;
            }
        }
        
        return rv;
    }
    
    @Override
    public void fetchItems(int listId)
    {
        Logcelot.log( "SimpleDataViewer.fetchItems()");
        itemData.clear();
        dataManager.fetchItems(listId, itemData);
    }
    
    @Override
    public void updateItemActiveness(ItemDesc item, boolean active)
    {
        Logcelot.log( "SimpleDataViewer.updateItemActiveness()");
        int itemId = item.getId();
        dataManager.updateItemActiveness(itemId, active);
        if(selectedList != null)
        {
            Logcelot.log( "SimpleDataViewer.updateItemActiveness().selectedList!=null");
            fetchItems(selectedList.getId());
        }
        fetchLists();
    }
    
    @Override
    public void updateItemStarness(ItemDesc item, boolean star)
    {
        Logcelot.log( "SimpleDataViewer.updateItemStarness()");
        int itemId = item.getId();
        dataManager.updateItemStarness(itemId, star);
        if(selectedList != null)
        {
            Logcelot.log( "SimpleDataViewer.updateItemStarness().selectedList!=null");
            fetchItems(selectedList.getId());
        }
        fetchLists();
    }
    
    @Override
    public void updateItemLabel(ItemDesc item, String newLabel)
    {
        Logcelot.log( "SimpleDataViewer.updateItemLabel()");
        int itemId = item.getId();
        dataManager.updateItemLabel(itemId, newLabel);
        if(selectedList != null)
        {
            Logcelot.log( "SimpleDataViewer.updateItemLabel().selectedList!=null");
            fetchItems(selectedList.getId());
        }
    }
    
    @Override
    public void updateListLabel(int listId, String newLabel)
    {
        Logcelot.log( "SimpleDataViewer.updateListLabel()");
        dataManager.updateListLabel(listId, newLabel);
        fetchLists();
    }
    
    @Override
    public void moveItem(ItemDesc item, int toListId)
    {
        Logcelot.log( "SimpleDataViewer.moveItem()");
        int itemId = item.getId();
        dataManager.moveItem(itemId, toListId);
        if(selectedList != null)
        {
            Logcelot.log( "SimpleDataViewer.moveItem().selectedList!=null");
            fetchItems(selectedList.getId());
        }
        fetchLists();
    }
    
    @Override
    public void createList(String label)
    {
        Logcelot.log( "SimpleDataViewer.createList()");
        dataManager.createList(label);
        fetchLists();
    }
    
    @Override
    public void createItem(String label)
    {
        Logcelot.log( "SimpleDataViewer.createItem()");
        int listId = selectedList.getId();
        dataManager.createItem(listId, label);
        fetchItems(listId);
    }
    
    @Override
    public void deleteInactive()
    {
        Logcelot.log( "SimpleDataViewer.deleteInactive()");
        if(selectedList == null)
        {
            Logcelot.log( "SimpleDataViewer.deleteInactive().selectedList!=null");
            Log.e(L.TAG, "deleteInactive() called but no list is selected");
            return;
        }
        Logcelot.log( "SimpleDataViewer.deleteInactive().selectedList==null");
        int listId = selectedList.getId();
        dataManager.deleteInactive(listId);
        fetchItems(listId);
        fetchLists();    
    }
    
    @Override
    public void deleteList(int listId)
    {
        Logcelot.log( "SimpleDataViewer.deleteList()");
        dataManager.deleteList(listId);
        fetchLists();
    }
    
    @Override
    public void deleteItem(ItemDesc item)
    {
        Logcelot.log( "SimpleDataViewer.deleteItem()");
        int itemId = item.getId();
        dataManager.deleteItem(itemId);
        if(selectedList != null)
        {
            Logcelot.log( "SimpleDataViewer.deleteItem().selectedList!=null");
            fetchItems(selectedList.getId());
        }
        fetchLists();
    }
    
    @Override
    public void invalidateCache()
    {
        Logcelot.log( "SimpleDataViewer.invalidateCache()");
        // no cache to void
    }
    
    @Override
    public void flush()
    {
        Logcelot.log( "SimpleDataViewer.flush()");
        // Do nothing
    }
    
    @Override
    public void close()
    {
        Logcelot.log( "SimpleDataViewer.close()");
        // Do nothing
    }

}
