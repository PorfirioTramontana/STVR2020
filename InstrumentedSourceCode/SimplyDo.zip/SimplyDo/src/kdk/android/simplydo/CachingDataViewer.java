/*
 * Copyright (C) 2010, 2011 Keith Kildare
 * 
 * This file is part of SimplyDo.
 * 
 * SimplyDo is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SimplyDo is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with SimplyDo.  If not, see <http://www.gnu.org/licenses/>.
 * 
 */
package kdk.android.simplydo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import android.util.Log;

import it.unina.dieti.logcelot.Logcelot;

/**
 * A cache of the database data which does the actual database calls lazily on
 * a separate thread. On my device a database write take 300ms-450ms which is
 * too log to hang onto the UI thread for.
 */
public class CachingDataViewer implements DataViewer
{
    private DataManager dataManager;
    
    private List<ItemDesc> itemData = new LinkedList<ItemDesc>();
    private List<ListDesc> listData = new ArrayList<ListDesc>();
    
    private Thread dbUpdateThread;
    private Object viewerLock = new Object();
    private LinkedList<ViewerTask> taskQueue = new LinkedList<ViewerTask>();

    // declared volatile since it is accessed in the db thread
    // without holding the viewerLock
    private volatile boolean running = false;
    
    private boolean interruptRequire = false;
    private ListDesc selectedList;

    
    public CachingDataViewer(DataManager dataManager)
    {
        Logcelot.log( "CachingDataViewer.CachingDataViewer()");
        this.dataManager = dataManager;
        
        dbUpdateThread = new Thread(new Runnable() {
            @Override
            public void run()
            {
                Logcelot.log( "CachingDataViewer.CachingDataViewer().run()");
                dbUpdateLoop();
            }
        }, "DB Update");
    }
    
    
    public void start()
    {
        Logcelot.log( "CachingDataViewer.start()");
        running = true;
        // start task queue
        
        dbUpdateThread.start();
    }
    
    @Override
    public void invalidateCache()
    {
        Logcelot.log( "CachingDataViewer.invalidateCache()");
        setSelectedList(null);
        fetchLists();
    }
    
    @Override
    public void flush()
    {
        Logcelot.log( "CachingDataViewer.flush()");
        flushTasks();
    }
    
    @Override
    public void close()
    {
        Logcelot.log( "CachingDataViewer.close()");
        Log.v(L.TAG, "CachingDataView.close(): Entered");
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.close().synchronized");
            flushTasksNoLock();
            
            running = false;
            
            if(interruptRequire)
            {
                Logcelot.log( "CachingDataViewer.close().synchronized.interruptRequire");
                Log.d(L.TAG, "CachingDataView.close(): Close interrupt required");
                dbUpdateThread.interrupt();
            }
        }        
        
        try
        {
            Logcelot.log( "CachingDataViewer.close().try");
            dbUpdateThread.join();
        }
        catch (InterruptedException e)
        {
            Logcelot.log( "CachingDataViewer.close().try.catchInterruptedException");
            Log.d(L.TAG, "CachingDataView.close(): shutdown join interrupted", e);
        }
        
        Log.v(L.TAG, "CachingDataView.close(): Exit");
    }


    @Override
    public List<ItemDesc> getItemData()
    {
        Logcelot.log( "CachingDataViewer.getItemData()");
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.getItemData().synchronized");
            return itemData;
        }
    }

    
    @Override
    public List<ListDesc> getListData()
    {
        Logcelot.log( "CachingDataViewer.getListData()");
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.getListData().synchronized");
            return listData;
        }
    }
    
    
    @Override
    public ListDesc getSelectedList()
    {
        Logcelot.log( "CachingDataViewer.getSelectedList()");
        return selectedList;
    }


    @Override
    public void setSelectedList(ListDesc selectedList)
    {
        Logcelot.log( "CachingDataViewer.setSelectedList()");
        flushTasks();
        
        // this is ok since this thread is the only source
        // of task and we've just flushed the task queue
        itemData.clear();
        if(selectedList != null)
        {
            Logcelot.log( "CachingDataViewer.setSelectedList().selectedList!=null");
            dataManager.fetchItems(selectedList.getId(), itemData);
        }
        
        this.selectedList = selectedList;
    }


    @Override
    public void fetchLists()
    {
        Logcelot.log( "CachingDataViewer.fetchLists()");
        Log.v(L.TAG, "CachingDataView.fetchLists(): Entered");
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.FETCH_LISTS;
        doTaskAndWait(task);
        Log.v(L.TAG, "CachingDataView.fetchLists(): Exited");
    }
    
    public ListDesc fetchList(int listId)
    {
        Logcelot.log( "CachingDataViewer.fetchList()");
        ListDesc rv = null;
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.fetchList().synchronized");
            for(ListDesc list : listData)
            {
                Logcelot.log( "CachingDataViewer.fetchList().synchronized.foreach.listData");
                if(listId == list.getId())
                {
                    Logcelot.log( "CachingDataViewer.fetchList().synchronized.foreach.listData.listId==list.getId()");
                    rv = list;
                    break;
                }
            }
        }

        return rv;
    }

    
    @Override
    public void fetchItems(int listId)
    {
        Logcelot.log( "CachingDataViewer.fetchItems()");
        Log.v(L.TAG, "CachingDataViewer.fetchItems(): Entered");
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.FETCH_ITEMS;
        task.args = new Object[]{listId};
        doTaskAndWait(task);
        Log.v(L.TAG, "CachingDataViewer.fetchItems(): Exited");
    }
    

    @Override
    public void createItem(String label)
    {
        Logcelot.log( "CachingDataViewer.createItem()");
        if(selectedList == null)
        {
            Logcelot.log( "CachingDataViewer.createItem().selectedList==null");
            Log.e(L.TAG, "CachingDataViewer.createItem(): called but no list is selected");
            return;
        }
        Logcelot.log( "CachingDataViewer.createItem().selectedList!=null");
        int listId = selectedList.getId();
        
        ItemDesc newItem = new ItemDesc(-1, label, true, false);
        
        ViewerTask createTask = new ViewerTask();
        createTask.taskId = ViewerTask.CREATE_ITEM;
        createTask.args = new Object[]{listId, label, newItem};
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.createItem().selectedList!=null.synchronized");
            // queue fetch lists
            taskQueue.add(createTask);
            viewerLock.notifyAll();
            
            itemData.add(0, newItem);
            
            updateListStats();
        }
    }


    @Override
    public void createList(String label)
    {
        Logcelot.log( "CachingDataViewer.createList()");
        ViewerTask createTask = new ViewerTask();
        createTask.taskId = ViewerTask.CREATE_LIST;
        createTask.args = new Object[]{label};

        ViewerTask fetchTask = new ViewerTask();
        fetchTask.taskId = ViewerTask.FETCH_LISTS;
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.createList().synchronized");
            // queue fetch lists
            taskQueue.add(createTask);
            taskQueue.add(fetchTask);
            viewerLock.notifyAll();
            
            flushTasksNoLock();
        }
    }


    @Override
    public void deleteInactive()
    {
        Logcelot.log( "CachingDataViewer.deleteInactive()");
        if(selectedList == null)
        {
            Logcelot.log( "CachingDataViewer.deleteInactive().selectedList==null");
            Log.e(L.TAG, "CachingDataViewer.deleteInactive() called but no list is selected");
            return;
        }
        Logcelot.log( "CachingDataViewer.deleteInactive().selectedList!=null");
        
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.DELETE_INACTIVE;
        task.args = new Object[]{selectedList.getId()};

        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.deleteInactive().selectedList!=null.synchronized");
            // queue fetch lists
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            // update items data
            List<ItemDesc> toDelete = new ArrayList<ItemDesc>();
            for(ItemDesc i : itemData)
            {
                Logcelot.log( "CachingDataViewer.deleteInactive().selectedList!=null.synchronized.for.itemData");
                if(!i.isActive())
                {
                    Logcelot.log( "CachingDataViewer.deleteInactive().selectedList!=null.synchronized.for.itemData.!i.isActive()");
                    toDelete.add(i);
                }
            }
            itemData.removeAll(toDelete);
            
            updateListStats();
        }
    }


    @Override
    public void deleteItem(ItemDesc item)
    {
        Logcelot.log( "CachingDataViewer.deleteItem()");
        itemIdBarrier(item);
        
        int itemId = item.getId();        
        
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.DELETE_ITEM;
        task.args = new Object[]{itemId};
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.deleteItem().synchronized");
            // queue fetch lists
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            // update items data
            itemData.remove(item);
            updateListStats();
        }
    }


    @Override
    public void deleteList(int listId)
    {
        Logcelot.log( "CachingDataViewer.deleteList()");
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.DELETE_LIST;
        task.args = new Object[]{listId};
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.deleteList().synchronized");
            // queue fetch lists
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            // update lists data
            ListDesc delete = null;
            for(ListDesc list : listData)
            {
                Logcelot.log( "CachingDataViewer.deleteList().synchronized.for.listData");
                if(listId == list.getId())
                {
                    Logcelot.log( "CachingDataViewer.deleteList().synchronized.for.listData.listId==list.getId()");
                    delete = list;
                    break;
                }
            }
            listData.remove(delete);
        }
        
    }


    @Override
    public void updateItemLabel(ItemDesc item, String newLabel)
    {
        Logcelot.log( "CachingDataViewer.updateItemLabel()");
        itemIdBarrier(item);
        int itemId = item.getId();
        
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.UPDATE_ITEM_LABEL;
        task.args = new Object[]{itemId, newLabel};
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.updateItemLabel().synchronized");
            // queue fetch lists
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            // update items data
            item.setLabel(newLabel);
        }        
    }


    @Override
    public void moveItem(ItemDesc item, int toListId)
    {
        Logcelot.log( "CachingDataViewer.moveItem()");
        itemIdBarrier(item);
        int itemId = item.getId();

        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.MOVE_ITEM;
        task.args = new Object[]{itemId, toListId};
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.moveItem().synchronized");
            // queue fetch lists
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            // remove from items data
            ItemDesc itemInList = null;
            for(ItemDesc i : itemData)
            {
                Logcelot.log( "CachingDataViewer.moveItem().synchronized.for.itemData");
                if(itemId == i.getId())
                {
                    Logcelot.log( "CachingDataViewer.moveItem().synchronized.for.itemData.itemId==i.getId()");
                    itemInList = i;
                    break;
                }
            }
            if(itemInList != null)
            {
                Logcelot.log( "CachingDataViewer.moveItem().synchronized.itemInList!=null");
                itemData.remove(itemInList);
                updateListStats();
                ListDesc toList = findList(toListId);
                toList.setTotalItems(toList.getTotalItems() + 1);
                if(itemInList.isActive())
                {
                    Logcelot.log( "CachingDataViewer.moveItem().synchronized.itemInList!=null.itemInList.isActive()");
                    toList.setActiveItems(toList.getActiveItems() + 1);
                }
            }
            else
            {
                Logcelot.log( "CachingDataViewer.moveItem().synchronized.itemInList==null");
                Log.w(L.TAG, "CachingDataViewer.moveItem(): Didn't find item in current item data");
            }
        }        
    }


    @Override
    public void updateListLabel(int listId, String newLabel)
    {
        Logcelot.log( "CachingDataViewer.updateListLabel()");
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.UPDATE_LIST_LABEL;
        task.args = new Object[]{listId, newLabel};
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.updateListLabel().synchronized");
            // queue fetch lists
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            // update items data
            for(ListDesc i : listData)
            {
                Logcelot.log( "CachingDataViewer.updateListLabel().synchronized.for.listData");
                if(listId == i.getId())
                {
                    Logcelot.log( "CachingDataViewer.updateListLabel().synchronized.for.listData.listId==i.getId()");
                    i.setLabel(newLabel);
                    break;
                }
            }
        }        
    }
    

    @Override
    public void updateItemActiveness(ItemDesc item, boolean active)
    {
        Logcelot.log( "CachingDataViewer.updateItemActiveness()");
        itemIdBarrier(item);
        int itemId = item.getId();
        
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.UPDATE_ACTIVENESS;
        task.args = new Object[]{itemId, active};
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.updateItemActiveness().synchronized");
            // queue fetch lists
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            // update items data
            item.setActive(active);
            
            // update lists data
            if(selectedList != null)
            {
                Logcelot.log( "CachingDataViewer.updateItemActiveness().synchronized.selectedList!=null");
                int activeItems = selectedList.getActiveItems();
                activeItems += active?1:-1;
                selectedList.setActiveItems(activeItems);
            }
        }
    }
    

    @Override
    public void updateItemStarness(ItemDesc item, boolean star)
    {
        Logcelot.log( "CachingDataViewer.updateItemStarness()");
        itemIdBarrier(item);
        int itemId = item.getId();
        
        ViewerTask task = new ViewerTask();
        task.taskId = ViewerTask.UPDATE_STARNESS;
        task.args = new Object[]{itemId, star};
        
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.updateItemStarness().synchronized");
            // queue fetch lists
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            // update items data
            item.setStar(star);
        }
    }
    
    
    private void itemIdBarrier(ItemDesc item)
    {
        Logcelot.log( "CachingDataViewer.itemIdBarrier()");
        if(item.getId() == -1)
        {
            Logcelot.log( "CachingDataViewer.itemIdBarrier().item.getId()==-1");
            Log.v(L.TAG, "CachingDataViewer.itemIdBarrier(): Used");
            flushTasks();
            
            if(item.getId() == -1)
            {
                Logcelot.log( "CachingDataViewer.itemIdBarrier().item.getId()==-1.item.getId()==-1");
                Log.e(L.TAG, "CachingDataViewer.itemIdBarrier(): failed!");
            }
        }
    }
    
    
    private void flushTasksNoLock()
    {
        Logcelot.log( "CachingDataViewer.flushTasksNoLock()");
        while(taskQueue.size() != 0)
        {
            Logcelot.log( "CachingDataViewer.flushTasksNoLock().while");
            try
            {
                Logcelot.log( "CachingDataViewer.flushTasksNoLock().while.try");
                viewerLock.wait(200);
            }
            catch (InterruptedException e)
            {
                Logcelot.log( "CachingDataViewer.flushTasksNoLock().while.try.catchInterruptedException");
                Log.e(L.TAG, "CachingDataViewer.flushTasksNoLock(): Exception waiting for flushTasksNoLock()", e);
            }
        }
    }
    
    private void flushTasks()
    {
        Logcelot.log( "CachingDataViewer.flushTasks()");
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.flushTasks().synchronized");
            flushTasksNoLock();
        }
    }
    
    private void updateListStats()
    {
        Logcelot.log( "CachingDataViewer.updateListStats()");
        updateListStats(selectedList);
    }
    
    private ListDesc findList(int listId)
    {
        Logcelot.log( "CachingDataViewer.findList()");
        ListDesc rvList = null;
        for(ListDesc list : listData)
        {
            Logcelot.log( "CachingDataViewer.for()");
            if(list.getId() == listId)
            {
                Logcelot.log( "CachingDataViewer.for().list.getId()==listId");
                rvList = list;
                break;
            }
        }

        return rvList;
    }
    
    
    private void updateListStats(ListDesc listDesc)
    {
        Logcelot.log( "CachingDataViewer.updateListStats()");
        listDesc.setTotalItems(itemData.size());
        int active = 0;
        for(ItemDesc item : itemData)
        {
            Logcelot.log( "CachingDataViewer.updateListStats().for");
            if(item.isActive())
            {
                Logcelot.log( "CachingDataViewer.updateListStats().for.item.isActive()");
                active++;
            }
        }
        listDesc.setActiveItems(active);
    }
    
    
    private void doTaskAndWait(ViewerTask task)
    {
        Logcelot.log( "CachingDataViewer.doTaskAndWait()");
        synchronized (viewerLock)
        {
            Logcelot.log( "CachingDataViewer.doTaskAndWait().synchronized");
            taskQueue.add(task);
            viewerLock.notifyAll();
            
            try
            {
                Logcelot.log( "CachingDataViewer.doTaskAndWait().synchronized.try");
                while(!task.done)
                {
                    Logcelot.log( "CachingDataViewer.doTaskAndWait().synchronized.try.while");
                    viewerLock.wait();
                }
            }
            catch(InterruptedException e)
            {
                Logcelot.log( "CachingDataViewer.doTaskAndWait().synchronized.try.catchInterruptedException");
                Log.e(L.TAG, "CachingDataViewer.doTaskAndWait(): Error waiting for task", e);
            }
        }
    }
    
    
    private void dbUpdateLoop()
    {
        Logcelot.log( "CachingDataViewer.dbUpdateLoop()");
        Log.v(L.TAG, "CachingDataViewer.dbUpdateLoop(): Entered");
        while(running)
        {
            Logcelot.log( "CachingDataViewer.dbUpdateLoop().while");
            try
            {
                Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try");
                // get task
                ViewerTask task;
                synchronized (viewerLock)
                {
                    Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.synchronized");
                    while(taskQueue.size() == 0)
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.synchronized.while");
                        interruptRequire = true;
                        viewerLock.wait();
                        interruptRequire = false;
                    }
                    task = taskQueue.peek();
                }
                
                boolean doNotify = true;
                try
                {
                    Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try");
                    // do it
                    switch(task.taskId)
                    {
                    case ViewerTask.FETCH_LISTS:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseFETCH_LISTS");
                        List<ListDesc> lists = dataManager.fetchLists();
                        synchronized (viewerLock)
                        {
                            Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseFETCH_LISTS.synchronized");
                            listData = lists;
                            task.done = true;
                            viewerLock.notifyAll();
                        }
                        doNotify = false;
                        break;
                    }
                    case ViewerTask.FETCH_ITEMS:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseFETCH_ITEMS");
                        synchronized (viewerLock)
                        {
                            Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseFETCH_ITEMS.synchronized");
                            itemData.clear();
                            dataManager.fetchItems((Integer)task.args[0], itemData);
                            task.done = true;
                            viewerLock.notifyAll();
                        }
                        doNotify = false;
                        break;
                    }
                    case ViewerTask.UPDATE_ACTIVENESS:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseUPDATE_ACTIVENESS");
                        dataManager.updateItemActiveness((Integer)task.args[0], (Boolean)task.args[1]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.UPDATE_STARNESS:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseUPDATE_STARNESS");
                        dataManager.updateItemStarness((Integer)task.args[0], (Boolean)task.args[1]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.UPDATE_ITEM_LABEL:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseUPDATE_ITEM_LABEL");
                        dataManager.updateItemLabel((Integer)task.args[0], (String)task.args[1]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.UPDATE_LIST_LABEL:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseUPDATE_LIST_LABEL");
                        dataManager.updateListLabel((Integer)task.args[0], (String)task.args[1]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.MOVE_ITEM:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseMOVE_ITEM");
                        dataManager.moveItem((Integer)task.args[0], (Integer)task.args[1]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.DELETE_LIST:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseDELETE_LIST");
                        dataManager.deleteList((Integer)task.args[0]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.DELETE_ITEM:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseDELETE_ITEM");
                        dataManager.deleteItem((Integer)task.args[0]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.DELETE_INACTIVE:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseDELETE_INACTIVE");
                        dataManager.deleteInactive((Integer)task.args[0]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.CREATE_LIST:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseCREATE_LIST");
                        dataManager.createList((String)task.args[0]);
                        task.done = true;
                        break;
                    }
                    case ViewerTask.CREATE_ITEM:
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseCREATE_ITEM");
                        ItemDesc item = (ItemDesc)task.args[2];
                        int id = dataManager.createItem((Integer)task.args[0], (String)task.args[1]);
                        item.setId(id);
                        task.done = true;
                        break;
                    }
                    default:
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.caseDEFAULT");
                        Log.w(L.TAG, "CachingDataViewer.dbUpdateLoop(): Unknown task enumeration " + task.taskId);
                    }
                }
                finally
                {
                    Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.finally");
                    synchronized (viewerLock)
                    {
                        Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.finally.synchronized");
                        taskQueue.remove();                
                        if(doNotify)
                        {
                            Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.finally.synchronized.doNotify");
                            viewerLock.notifyAll();
                        }
                    }
                }                
            }
            catch(InterruptedException e)
            {
                Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.catchInterruptedException");
                if(running)
                {
                    Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.catchInterruptedException.running");
                    Log.e(L.TAG, "CachingDataViewer.dbUpdateLoop(): Interrupted in DB update loop", e);
                }
                else
                {
                    Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.try.catchInterruptedException.!running");
                    Log.d(L.TAG, "CachingDataViewer.dbUpdateLoop(): interrupt exit");
                }
            }
            catch(Exception e)
            {
                Logcelot.log( "CachingDataViewer.dbUpdateLoop().while.try.catchException");
                Log.e(L.TAG, "CachingDataViewer.dbUpdateLoop(): Exception in DB update loop", e);
            }
        }
        Log.v(L.TAG, "CachingDataViewer.dbUpdateLoop(): Exit");
    }
    
    
    private static class ViewerTask
    {
        private static final int FETCH_LISTS = 0;
        private static final int FETCH_ITEMS = 1;
        private static final int UPDATE_ACTIVENESS = 2;
        private static final int UPDATE_ITEM_LABEL = 3;
        private static final int UPDATE_LIST_LABEL = 4;
        private static final int DELETE_LIST = 5;
        private static final int DELETE_ITEM = 6;
        private static final int DELETE_INACTIVE = 7;
        private static final int CREATE_LIST = 8;
        private static final int CREATE_ITEM = 9;
        private static final int UPDATE_STARNESS = 10;
        private static final int MOVE_ITEM = 11;
        
        private int taskId;
        private Object[] args;
        private boolean done = false;
    }

}
