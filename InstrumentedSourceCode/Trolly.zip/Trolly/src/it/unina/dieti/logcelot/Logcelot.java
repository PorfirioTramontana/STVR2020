package it.unina.dieti.logcelot;

/**
 * Created by Alessandro on 24/05/2017.
 */
import android.util.Log;

import java.util.ArrayList;
import java.util.UUID;

// final Prevents extension of the class since extending a static class makes no sense
public final class Logcelot {
    //Since the class cannot be instantiated no instance methods can be called or instance fields accessed

    //private StrategyType strategy;

    //- Un codice identificativo costante che consente all' utilizzatore di riconoscere che il log è stato scritto con questa libreria.
    private static final String signCode = "Logcelot";

    // Un codice casuale costante per tuta l' esecuzione ( utile per identificare la singola esecuzione )
    private static final String executionCode = UUID.randomUUID().toString();

    // Un intero identificativo progressivo ( se il log A viene stampato prima del log B allora ha un codice identificativo minore)
    private static long progressiveCode = 0;

    // Orario di sistema all' inizio
    private static long systemTime = 0;

    // Tempo passato dalla stampa del primo log
    private static long timeElapsed = 0;

    // Il nome del package della classe chiamante
    private static String callingPackage = "neverCalledByAPackage";

    // Il nome della classe chiamante
    private static String callingClass = "neverCalledByAClass";

    // ( opzionale ) un tag definibile dall' utente
    private static String customTag = null;

    // ( opzionale ) un argomento definibile dall' utente
    private static String customArgument = null;

    // Lista contenente tutti gli argomenti distinti scritti su log
    private static ArrayList<String> distinctCustomArguments;

    // Tipo
    public enum LogTypeEnum{
        INIZIOMETODO,
        FINEMETODO,
        INIZIOCOSTRUTTORE,
        FINECOSTRUTTORE,
        IFTHEN,
        ELSE,
        LOOP, // FOR
        WHILE,
        SWITCHCASE,
        EXCEPTION,
        DEFAULT
    };
    private static LogTypeEnum logType;

    // Livello
    public enum LogLevelEnum{
        VERBOSE,
        DEBUG,
        INFO,
        WARN,
        ERROR
    }
    private static LogLevelEnum logLevel;

    private static Boolean configSetted = false;
    private static Boolean enabled = false;

    // Constructor private Prevents instantiation by client code as it makes no sense to instantiate a static class
    private Logcelot( ){
        //Never accessed
        assert(false);
    };

    // configurazioni opzionali
    public static void setConfig(  LogTypeEnum type, LogLevelEnum level ){
        if( !configSetted ) {
            systemTime = System.currentTimeMillis();
            distinctCustomArguments = new ArrayList<String>();
            logType = type;
            logLevel = level;
            configSetted = true;
        }
    }

    // configurazione di default
    public static void setConfig(){
        if( !configSetted ) {
            systemTime = System.currentTimeMillis();
            distinctCustomArguments = new ArrayList<String>();
            logType = LogTypeEnum.DEFAULT;
            logLevel = LogLevelEnum.VERBOSE;
            configSetted = true;
        }
    }

    public static void enableLogging(){
        if(configSetted)
            enabled = true;
    }

    public static void disableLoging(){
        enabled = false;
    }

    /*public static void log( Activity activity,
                            //String tag,
                            String argument ){
        if( enabled ){
            progressiveCode++;
            timeElapsed = System.currentTimeMillis() - systemTime;
            callingPackage = activity.getCallingPackage();
            callingClass = activity.getLocalClassName();
            //customTag = tag;
            customArgument = argument;
            String msg = progressiveCode + "|" +
                    timeElapsed + "|" +
                    callingPackage + "|" +
                    callingClass + "|" +
                    //customTag + "|" +
                    customArgument;
            Log.d( signCode+"/"+executionCode, msg );
        }
    }

    public static void log( Activity activity ){
        if( enabled ) {
            progressiveCode++;
            timeElapsed = System.currentTimeMillis() - systemTime;
            callingPackage = activity.getCallingPackage();
            callingClass = activity.getLocalClassName();
            String msg = progressiveCode + "|" +
                    timeElapsed + "|" +
                    callingPackage + "|" +
                    callingClass;
            Log.d( signCode+"/"+executionCode, msg );
        }
    }

    public static void log(){
        if( enabled ) {
            progressiveCode++;
            timeElapsed = System.currentTimeMillis() - systemTime;
            String msg = progressiveCode + "|" +
                    timeElapsed;
            Log.d( signCode+"/"+executionCode, msg );
        }
    }
    */

    public static void log( String argument ){
        if( enabled ) {
            progressiveCode++;
            if(!distinctCustomArguments.contains(argument))
                distinctCustomArguments.add(argument);
            timeElapsed = System.currentTimeMillis() - systemTime;
            customArgument = argument;
            String msg = progressiveCode + "|" +
                    distinctCustomArguments.size() + "|" +
                    timeElapsed + "|" +
                    customArgument;
            Log.d( signCode+"/"+executionCode, msg );
        }
        else{
            if ( configSetted ) {
                //stub enable=true ?
            }else{
                //stub setDefaultConfig?
            }
        }
    }
}
