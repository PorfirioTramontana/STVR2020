/** Automatically generated file. DO NOT MODIFY */
package info.bpace.munchlife;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}