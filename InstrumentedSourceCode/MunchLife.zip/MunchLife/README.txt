MunchLife is a very simple counter application for keeping track of your level while you're playing the card game Munchkin(tm). Released under the GPL version 3, see LICENSE.txt.

http://www.worldofmunchkin.com/game/

Application released on Android Marketplace.