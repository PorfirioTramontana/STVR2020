/*
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package info.bpace.munchlife;

import android.app.Activity;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.Preference.OnPreferenceChangeListener;
import android.widget.Toast;

import android.util.Log;

import it.unina.dieti.logcelot.Logcelot;

public class SettingsActivity extends PreferenceActivity
{
	OnPreferenceChangeListener levelListener = new OnPreferenceChangeListener()
	{
		public boolean onPreferenceChange(Preference pref, Object newValue)
		{
			Logcelot.log( "SettingsActivity.levelListener");
			int value = 0;
			try
			{
				Logcelot.log( "SettingsActivity.levelListener.try");
				value = Integer.parseInt(newValue.toString());
			}
			catch(NumberFormatException error)
			{
				Logcelot.log( "SettingsActivity.levelListener.try.catchNumberFormatException");
				Log.w(MunchLifeActivity.TAG, 
              "NumberFormatException: " + error.getMessage());
			}
		
			if(value > 1 && value <= 100)
			{
				Logcelot.log( "SettingsActivity.levelListener.try.catchNumberFormatException.(value > 1 && value <= 100)");
				return true;
			}
			else
			{
				Logcelot.log( "SettingsActivity.levelListener.try.catchNumberFormatException.(value > 1 && value <= 100).else");
				Toast.makeText(getApplicationContext(),
                       R.string.maxlevelError,
                       Toast.LENGTH_SHORT).show();
				return false;
			}
		}
	};
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		Logcelot.log( "SettingsActivity.onCreate()");
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.preferences);
		Preference levelPreference;
    levelPreference = getPreferenceScreen().findPreference("maxlevelPref");
		levelPreference.setOnPreferenceChangeListener(levelListener);
	}
}
